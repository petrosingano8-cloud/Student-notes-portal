require("dotenv").config();
const express = require("express");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const OpenAI = require("openai");

const app = express();
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

const DATA = path.join(__dirname,"data");
fs.mkdirSync(DATA,{recursive:true});
const notesFile=path.join(DATA,"notes.json");
const studentsFile=path.join(DATA,"students.json");
if(!fs.existsSync(notesFile)) fs.writeFileSync(notesFile,"[]");
if(!fs.existsSync(studentsFile)) fs.writeFileSync(studentsFile,"[]");

const sessions=new Map();
const openai = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;

function read(file){return JSON.parse(fs.readFileSync(file,"utf8"))}
function write(file,data){fs.writeFileSync(file,JSON.stringify(data,null,2))}
function auth(req,res,next){
 const h=req.headers.authorization||"";
 const token=h.startsWith("Bearer ")?h.slice(7):"";
 if(!sessions.has(token)) return res.status(401).json({error:"Admin login required."});
 next();
}

app.get("/api/notes",(req,res)=>{
 const form=String(req.query.form||"");
 const notes=read(notesFile).filter(n=>String(n.form)===form);
 res.json(notes);
});

app.post("/api/register",(req,res)=>{
 const {name,email,dob,form}=req.body||{};
 if(!name||!email||!dob||![1,2,3,4].includes(Number(form))) return res.status(400).json({error:"Please complete all registration fields."});
 const students=read(studentsFile);
 if(students.some(s=>s.email.toLowerCase()===String(email).toLowerCase())) return res.status(409).json({error:"That email is already registered."});
 students.push({id:crypto.randomUUID(),name:String(name).trim(),email:String(email).trim().toLowerCase(),dob:String(dob),form:Number(form),registeredAt:new Date().toISOString()});
 write(studentsFile,students);
 res.json({message:"Registration successful."});
});

app.post("/api/admin/login",(req,res)=>{
 const {username,password}=req.body||{};
 if(username!==process.env.ADMIN_USERNAME || password!==process.env.ADMIN_PASSWORD) return res.status(401).json({error:"Invalid admin login."});
 const token=crypto.randomBytes(32).toString("hex");
 sessions.set(token,{createdAt:Date.now()});
 res.json({token});
});

app.get("/api/admin/students",auth,(req,res)=>res.json(read(studentsFile)));
app.post("/api/admin/notes",auth,(req,res)=>{
 const {form,subject,title,content}=req.body||{};
 if(![1,2,3,4].includes(Number(form))||!subject||!title||!content) return res.status(400).json({error:"Complete all note fields."});
 const notes=read(notesFile);
 notes.unshift({id:crypto.randomUUID(),form:Number(form),subject:String(subject).trim(),title:String(title).trim(),content:String(content).trim(),createdAt:new Date().toISOString()});
 write(notesFile,notes);
 res.json({message:"Note added successfully."});
});

app.post("/api/ask",async(req,res)=>{
 const question=String(req.body?.question||"").trim();
 if(!question) return res.status(400).json({error:"Ask a school question."});
 if(question.length>2000) return res.status(400).json({error:"Question is too long."});
 if(!openai) return res.status(503).json({error:"AI is not configured. Add OPENAI_API_KEY on the server."});

 try{
   const response=await openai.responses.create({
     model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
     instructions:`You are the School AI for a secondary-school notes website.
Only answer educational/school questions appropriate for students aged 13-17.
Subjects can include Mathematics, Biology, Physics, Chemistry, English, Chichewa, Computer Studies, Technical Drawing, Geography, History and related school topics.
If a request is not a school/learning question, politely say: "I can only help with school and learning questions."
Explain answers clearly and do not help with dangerous activities, sexual content, gambling, drugs, weapons, or attempts to bypass school/age rules.
Do not ask for or reveal personal information. Encourage students to learn rather than simply copy answers.`,
     input: question,
     max_output_tokens: 700
   });
   res.json({answer:response.output_text||"I could not produce an answer."});
 }catch(err){
   console.error(err);
   res.status(500).json({error:"The school AI could not answer right now."});
 }
});

const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log(`Student Notes Portal running on http://localhost:${PORT}`));