# Student Notes Portal

## Features
- Form 1, Form 2, Form 3 and Form 4 notes
- Student registration: name, email, date of birth and form
- Admin login
- Admin can add notes
- Admin can view registrations
- School-only AI powered through the OpenAI API
- API key stays on the server, not in the browser

## Run locally
1. Install Node.js.
2. Open a terminal in this folder.
3. Run: `npm install`
4. Copy `.env.example` to `.env`.
5. Set a strong `ADMIN_PASSWORD`.
6. Put your OpenAI API key in `.env` as `OPENAI_API_KEY`.
7. Run: `npm start`
8. Open `http://localhost:3000`.

## Important production notes
This starter stores registrations and notes in JSON files. For a real public school portal, move them to a proper database and add HTTPS, stronger authentication, rate limiting, backups, access controls and a privacy policy.

The OpenAI API key must remain server-side. Do not put it in index.html or browser JavaScript.
